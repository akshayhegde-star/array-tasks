// Print an array in reverse order without using inbuilt methods
// Let arr = [23,45,67,78,89,90];
// Output = [90,89,78,67,45,23]


let arr = [23, 45, 67, 78, 89, 90];
let reversed = [];
// const reversed = arr.reverse();
// console.log(reversed);
for (let i = 0; i = arr.length; i++) {
    reversed.push(arr.pop());
}
document.write(reversed);