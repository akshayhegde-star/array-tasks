// Write a Program to find the maximum number in an array
// Let arr = [23,45,12,34,455,66,45,21,127];
// Output 455 is maximum

let arr = [23, 45, 12, 34, 455, 66, 45, 21, 127];
let max = Math.max(23, 45, 12, 34, 455, 66, 45, 21, 127);
document.write('<h3>' + max + '</h3>');