// Write a program to  find the two number in which there  sum should be  equal to target for example target = 10  
// Sample I/O
// Input let array = [2,3,5, 7,9,0];
// Output = 3,7;
// If you didn't find the two numbers in a particular array just return false
// Note : target has to take from prompt 

let array = [2, 3, 5, 7, 9, 0];
let sum = 10;
for (let i = 0; i < array.length; i++) {
    for (let j = i + 1; j < array.length; j++) {
        if (array[i] + array[j] === sum) {
            console.log(array[i], array[j]);
        }
    }
}