// Write a program to check peak exist in the array or not
// Peak: if the particular number is greater than to its left side number and right side number then it is called peak
// Input : [12,32,44,55,11,33,56];

let array = [12, 32, 44, 55, 11, 33, 56];
for (let i = 0; i <= array.length; i++) {
    if (array[i] > array[i - 1] && array[i] > array[i + 1]) {
        document.write('<h3>' + array[i] + '</h2>');
    }
}