// Program to display all the element which doesn’t  contains  letter ‘a’ in  the array
//           Sample  I/O:
//          Input  Let arr = [apple,orange,fruit,banana];
//          Output     	fruit



let arr = ['apple', 'orange', 'fruit', 'banana'];
for (let i = 0; i < arr.length; i++) {
    let splitArr = arr[i].split('');
    if (splitArr.indexOf('a') === -1)
        document.write(arr[i]);

}